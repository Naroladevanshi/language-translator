package com.infy.userinterface;

import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.infy.model.Employee;
import com.infy.validator.Validator;

public class Tester {
	
	private static final Log LOGGER = LogFactory.getLog(Tester.class);
	
	public static void main(String[] args) throws Exception{		
		try {
			Employee employee = new Employee("", 1234);
			new Validator().validate(employee);
			LOGGER.info("The employee details are successfully validated.");
		} 
		catch (Exception exception) {
			LOGGER.info(new Configurations().properties("configuration.properties").getProperty(exception.getMessage()));
		}
	}
}
